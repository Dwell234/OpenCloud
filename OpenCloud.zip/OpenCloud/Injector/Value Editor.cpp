#include <Windows.h>
#include <vector>

constexpr uint64_t kPageMask = 0xfffffffffffff000;
constexpr uint64_t kPageHash = 0x84B3A57D90E73527;
constexpr uint64_t offInsert = 0xC43D00;
constexpr uint64_t offWhitelist = 0x29C758;

class Bypass {
private:
    HANDLE p;
    uintptr_t base;
    uintptr_t insertSet;
    uintptr_t whitelistedPages;
    
    uint64_t Decrypt(uint64_t hash) {
        return hash ^ kPageHash;
    }
    
    void MarkValid(uintptr_t addr) {
        uint64_t page = (addr & kPageMask) >> 12;
        uint64_t hash = Decrypt(page);
        WriteProcessMemory(p, (LPVOID)(insertSet + (hash * 8)), &hash, 8, NULL);
    }
    
    void InjectShellcode(std::vector<uint8_t>& code) {
        void* loc = VirtualAllocEx(p, NULL, code.size(), MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
        WriteProcessMemory(p, loc, code.data(), code.size(), NULL);
        MarkValid((uintptr_t)loc);
    }
    
public:
    Bypass(HANDLE proc, uintptr_t b) : p(proc), base(b) {
        insertSet = base + offInsert;
        whitelistedPages = base + offWhitelist;
    }
    
    void Execute(std::vector<uint8_t>& code) {
        InjectShellcode(code);
    }
};