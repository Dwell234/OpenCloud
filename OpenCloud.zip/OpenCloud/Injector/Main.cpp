#include <Windows.h>
#include <TlHelp32.h>
#include <vector>

uintptr_t GetProc(const wchar_t* name) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32W pe = { sizeof(PROCESSENTRY32W) };
    if (Process32FirstW(snap, &pe)) {
        do {
            if (!_wcsicmp(pe.szExeFile, name)) {
                CloseHandle(snap);
                return (uintptr_t)OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return 0;
}

void* MapDLL(HANDLE p, const char* dll) {
    HANDLE f = CreateFileA(dll, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    DWORD sz = GetFileSize(f, NULL);
    std::vector<uint8_t> bytes(sz);
    DWORD rd;
    ReadFile(f, bytes.data(), sz, &rd, NULL);
    CloseHandle(f);
    void* loc = VirtualAllocEx(p, NULL, sz, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    WriteProcessMemory(p, loc, bytes.data(), sz, NULL);
    return loc;
}

int main() {
    HANDLE p = (HANDLE)GetProc(L"RobloxPlayerBeta.exe");
    if (!p) return 1;
    MapDLL(p, "payload.dll");
    return 0;
}