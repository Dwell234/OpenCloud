local DS = game:GetService("DataStoreService")
local Http = game:GetService("HttpService")

local function corrupt()
    local store = DS:GetDataStore("Test")
    local payloads = {
        function() return pcall(function() store:SetAsync("x", workspace) end) end,
        function() return pcall(function() store:SetAsync("x", "\255") end) end,
        function() return pcall(function() store:SetAsync("x", string.rep("a", 9999999)) end) end,
        function() return pcall(function() store:SetAsync("x", {[0/0]=true}) end) end,
    }
    for _, f in pairs(payloads) do f() end
end

local function rollback(ev, args)
    local mod = {}
    for k, v in pairs(args) do
        if type(v) == "string" then mod[k] = "\255" .. v
        elseif type(v) == "number" then mod[k] = 0/0
        else mod[k] = workspace end
    end
    ev:FireServer(unpack(mod))
end

return { corrupt = corrupt, rollback = rollback }