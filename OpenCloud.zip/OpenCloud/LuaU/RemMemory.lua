local function exploit(ev, args)
    local mod = {}
    for k, v in pairs(args) do
        if type(v) == "string" then
            mod[k] = "\255" .. v
        elseif type(v) == "number" then
            mod[k] = 0/0
        elseif type(v) == "boolean" then
            mod[k] = nil
        else
            mod[k] = workspace
        end
    end
    ev:FireServer(unpack(mod))
end

local function flood(ev, count, args)
    for i = 1, count do
        task.spawn(function()
            ev:FireServer(unpack(args))
        end)
    end
end

return { exploit = exploit, flood = flood }