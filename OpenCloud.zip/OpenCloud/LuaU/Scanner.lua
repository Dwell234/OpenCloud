local function scan(parent, path)
    local vulns = {}
    for _, c in pairs(parent:GetChildren()) do
        local p = path .. "." .. c.Name
        if c:IsA("RemoteEvent") or c:IsA("RemoteFunction") then
            table.insert(vulns, { name = c.Name, path = p, type = c.ClassName })
        end
        for _, v in pairs(scan(c, p)) do table.insert(vulns, v) end
    end
    return vulns
end

local RS = game:GetService("ReplicatedStorage")
local SS = game:GetService("ServerScriptService")
local vulns = {}
for _, v in pairs(scan(RS, "RS")) do table.insert(vulns, v) end
for _, v in pairs(scan(SS, "SS")) do table.insert(vulns, v) end
return vulns