#include <Windows.h>
#include <vector>

using NtReadVM = NTSTATUS(NTAPI*)(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
using NtWriteVM = NTSTATUS(NTAPI*)(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);

template<typename T>
T SyscallRead(HANDLE proc, uintptr_t addr) {
    T val;
    SIZE_T rd;
    NtReadVM ntRead = (NtReadVM)GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtReadVirtualMemory");
    ntRead(proc, (PVOID)addr, &val, sizeof(T), &rd);
    return val;
}

template<typename T>
void SyscallWrite(HANDLE proc, uintptr_t addr, T val) {
    SIZE_T wr;
    NtWriteVM ntWrite = (NtWriteVM)GetProcAddress(GetModuleHandleA("ntdll.dll"), "NtWriteVirtualMemory");
    ntWrite(proc, (PVOID)addr, &val, sizeof(T), &wr);
}

uintptr_t GetBase(HANDLE proc) {
    std::vector<uint8_t> buf(4096);
    ReadProcessMemory(proc, (LPCVOID)0x7FFE0000, buf.data(), 4096, NULL);
    for (size_t i = 0; i < 4096 - 8; i++) {
        if (*(uint64_t*)(buf.data() + i) == 0x0000000000000000) continue;
        // PEB walking logic
    }
    return 0;
}