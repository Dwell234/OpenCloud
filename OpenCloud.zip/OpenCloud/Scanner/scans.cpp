#include <Windows.h>
#include <vector>
#include <string>

class Scanner {
public:
    static uintptr_t FindPattern(HANDLE proc, uintptr_t start, size_t size, const std::string& sig, const std::string& mask) {
        std::vector<uint8_t> buf(size);
        ReadProcessMemory(proc, (LPCVOID)start, buf.data(), size, NULL);
        
        for (size_t i = 0; i < size - sig.size(); i++) {
            bool match = true;
            for (size_t j = 0; j < sig.size(); j++) {
                if (mask[j] == 'x' && buf[i + j] != (uint8_t)sig[j]) {
                    match = false;
                    break;
                }
            }
            if (match) return start + i;
        }
        return 0;
    }
    
    static uintptr_t FindString(HANDLE proc, uintptr_t start, size_t size, const std::string& str) {
        std::vector<uint8_t> buf(size);
        ReadProcessMemory(proc, (LPCVOID)start, buf.data(), size, NULL);
        for (size_t i = 0; i < size - str.size(); i++) {
            if (memcmp(buf.data() + i, str.c_str(), str.size()) == 0)
                return start + i;
        }
        return 0;
    }
};