#include <Windows.h>
#include <TlHelp32.h>
#include <vector>
#include <string>

namespace Offsets {
    constexpr uint16_t SCF_INSERTED_JMP = 0x04EB;
    constexpr uint32_t SCF_END_MARKER = 0xF4CC02EB;
    constexpr uintptr_t SCF_MARKER_STK = 0xDEADBEEFDEADC0DE;
    constexpr uint64_t kPageMask = 0xfffffffffffff000;
    constexpr uint8_t kPageShift = 0xc;
    constexpr uint64_t kPageHash = 0x84B3A57D90E73527;
    constexpr uint64_t Offset_InsertSet = 0xC43D00;
    constexpr uint64_t Offset_WhitelistedPages = 0x29C758;
}

uintptr_t GetProcBase(const wchar_t* proc) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
    PROCESSENTRY32W pe = { sizeof(PROCESSENTRY32W) };
    if (Process32FirstW(snap, &pe)) {
        do {
            if (!_wcsicmp(pe.szExeFile, proc)) {
                CloseHandle(snap);
                return (uintptr_t)OpenProcess(PROCESS_ALL_ACCESS, FALSE, pe.th32ProcessID);
            }
        } while (Process32NextW(snap, &pe));
    }
    CloseHandle(snap);
    return 0;
}

void* MapDLL(HANDLE proc, const char* dll) {
    HANDLE file = CreateFileA(dll, GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_EXISTING, 0, NULL);
    DWORD sz = GetFileSize(file, NULL);
    std::vector<uint8_t> bytes(sz);
    DWORD rd;
    ReadFile(file, bytes.data(), sz, &rd, NULL);
    CloseHandle(file);
    
    void* loc = VirtualAllocEx(proc, NULL, sz, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE);
    WriteProcessMemory(proc, loc, bytes.data(), sz, NULL);
    return loc;
}

int main() {
    HANDLE proc = (HANDLE)GetProcBase(L"RobloxPlayerBeta.exe");
    if (!proc) return 1;
    MapDLL(proc, "payload.dll");
    return 0;
}