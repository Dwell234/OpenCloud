#include <Windows.h>
#include <vector>
#include <string>
#include <glm/glm.hpp>

struct Vec3 { float x, y, z; };

class ESP {
private:
    HANDLE proc;
    uintptr_t base;
    HWND overlay;
    
    template<typename T>
    T Read(uintptr_t addr) {
        T val;
        ReadProcessMemory(proc, (LPCVOID)addr, &val, sizeof(T), NULL);
        return val;
    }
    
    Vec3 ReadVec3(uintptr_t addr) {
        Vec3 v;
        ReadProcessMemory(proc, (LPCVOID)addr, &v, sizeof(Vec3), NULL);
        return v;
    }
    
    uintptr_t GetLocalPlayer() {
        return Read<uintptr_t>(base + 0x1234567); // offset
    }
    
    uintptr_t GetPlayerPtr(int idx) {
        return Read<uintptr_t>(base + 0x7654321 + (idx * 8));
    }
    
    std::vector<uintptr_t> GetPlayers() {
        std::vector<uintptr_t> players;
        int count = Read<int>(base + 0x1111111);
        for (int i = 0; i < count; i++) {
            players.push_back(GetPlayerPtr(i));
        }
        return players;
    }
    
    Vec3 GetPosition(uintptr_t charPtr) {
        uintptr_t part = Read<uintptr_t>(charPtr + 0x2222222);
        return ReadVec3(part + 0x3333333);
    }
    
    void DrawBox(Vec3 pos, Vec3 size, int color) {
        // Overlay rendering
    }
    
public:
    ESP(HANDLE p, uintptr_t b) : proc(p), base(b) {}
    
    void Render() {
        auto players = GetPlayers();
        for (auto p : players) {
            uintptr_t charPtr = Read<uintptr_t>(p + 0x4444444);
            if (!charPtr) continue;
            Vec3 pos = GetPosition(charPtr);
            DrawBox(pos, {2, 4, 2}, 0x00FF00);
        }
    }
};